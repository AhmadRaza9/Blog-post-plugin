<?php

/**
 * Fired during plugin activation
 *
 * @link       https://ahmadraza.ga
 * @since      1.0.0
 *
 * @package    Blog_Post
 * @subpackage Blog_Post/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Blog_Post
 * @subpackage Blog_Post/includes
 * @author     Ahmad raza <raza.ataki@gmail.com>
 */
class Blog_Post_Activator
{

    /**
     * Short Description. (use period)
     *
     * Long Description.
     *
     * @since    1.0.0
     */
    public static function activate()
    {
        require_once BLOG_POST_BASE_DIR . 'includes/class-blog-post-type.php';
        // Register CPT   Add cpt and taxonomie  First Step
        $plugin_post_type = new Blog_Post_Types(BLOG_POST_NAME, BLOG_POST_VERSION);
        $plugin_post_type->init();

// Flush permalinks   Add cpt and taxonomie  First Step
        flush_rewrite_rules(true);

    }

}
