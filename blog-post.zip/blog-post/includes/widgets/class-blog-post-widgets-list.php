<?php

// If this file is call directyl, abort.
if (!defined('ABSPATH')) {
    die;
}

/**
 * Controlling all the widgets for plugin
 *
 * @package Blog_Post
 * @subpackage Blog_Post/includes
 * @author Ahmad <raza.ataki@gmail.com>
 */

if (!class_exists('Blog_Post_Widgets_List')) {
    class Blog_Post_Widgets_List extends WP_Widget
    {

        /**
         * The ID of this plugin.
         *
         * @since 1.0.0
         * @access private
         * @var string $plugin_name This id of this plugin
         */

        private $plugin_name;

        /**
         * The version of this plugin
         *
         * @since 1.0.0
         * @access private
         * @param string $plugin_version The Current version of this plugin
         */

        private $version;

        /**
         * Sets up the widgets name etc
         */
        public function __construct()
        {
            $widget_ops = array(
                'classname' => 'blog_post_list',
                'description' => __('Blog Post Lists', 'blog-post'),
            );
            parent::__construct('blog_post_list', __('Blog Post Lists', 'blog-post'), $widget_ops);
        }

        /**
         * Outputs the content of the widget
         *
         * @param array $args
         * @param array $instance
         */
        public function widget($args, $instance)
        {
            // outputs the content of the widget
            $title = $instance['title'];
            $show_blog = $instance['show_blog'];
            $order = $instance['order'];
            echo $args['before_widget'];
            echo $args['before_title'] . $title . $args['after_title'];
            $this->Blog_Post_List($show_blog, $order);
            echo $args['after_widget'];
        }

        /**
         * Outputs the options form on admin
         *
         * @param array $instance The widget options
         */
        public function form($instance)
        {
            // outputs the options form on admin
            if (isset($instance['title']) && isset($instance['show_blog']) && isset($instance['order'])) {
                $title = $instance['title'];
                $show_blog = $instance['show_blog'];
                $order = $instance['order'];

            } else {
                $title = __('Your title', 'blog-post');
                $show_blog = __(5, 'blog-post');
                $order = __('DESC', 'blog-post');

            }
            ?>

<p>
<label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title:');?></label>
<input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo esc_attr($title); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id('show_blog'); ?>"><?php _e('Number of Blogs to Show:');?></label>
<input class="widefat" id="<?php echo $this->get_field_id('show_blog'); ?>" name="<?php echo $this->get_field_name('show_blog'); ?>" type="number" value="<?php echo esc_attr($show_blog); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id('order'); ?>"><?php _e('Order of Blogs:');?></label>
<input class="widefat" id="<?php echo $this->get_field_id('order'); ?>" name="<?php echo $this->get_field_name('order'); ?>" type="text" value="<?php echo esc_attr($order); ?>" />
</p>

            <?php

        }

        /**
         * Processing widget options on save
         *
         * @param array $new_instance The new options
         * @param array $old_instance The previous options
         *
         * @return array
         */
        public function update($new_instance, $old_instance)
        {
            // processes widget options to be saved
            $instance = array();
            $instance['title'] = (!empty($new_instance['title'])) ? strip_tags($new_instance['title']) : '';
            $instance['show_blog'] = (!empty($new_instance['show_blog'])) ? strip_tags($new_instance['show_blog']) : '';
            $instance['order'] = (!empty($new_instance['order'])) ? strip_tags($new_instance['order']) : '';
            return $instance;

        }

        public function Blog_Post_List($limit, $order)
        {

            $args = array(
                'post_type' => 'blogs',
                'posts_per_page' => $limit,
                'order' => $order,
            );

            query_posts($args);

            if (have_posts()):
                while (have_posts()):
                    the_post();
                    ?>
																																																<ul>
																																																    <li>
																																																        <?php the_title(sprintf('<a class="blog-entry-title"><a href="%s" rel="blogmark">', esc_url(get_permalink())), '</a>');?>
																																																    </li>
																																																</ul>
																																																<?php

                endwhile;
            endif;

        }
    }
}