<?php

// If this file is call directyl, abort.
if (!defined('ABSPATH')) {
    die;
}

/**
 * Plugin Shortcode Functionaliity
 * @package    Blog_Post
 * @subpackage Blog_Post/includes
 * @author     Ahmad <raza.ataki@gmail.com>
 */

if (!class_exists('Blog_Post_Shortcodes')) {

    class Blog_Post_Shortcodes
    {

        /**
         * The ID of this plugin.
         *
         * @since    1.0.0
         * @access   private
         * @var      string    $plugin_name    The ID of this plugin.
         */
        private $plugin_name;

        /**
         * The version of this plugin.
         *
         * @since    1.0.0
         * @access   private
         * @var      string    $version    The current version of this plugin.
         */
        private $version;

        /**
         * It will be hold all the css for all shortcodes
         */

        protected $shortcode_css;

        /**
         * Temple loader class
         */

        private $template_loader;

        /**
         * Initialize the class and set its properties.
         *
         * @since    1.0.0
         * @param      string    $plugin_name       The name of the plugin.
         * @param      string    $version    The version of this plugin.
         */
        public function __construct($plugin_name, $version)
        {

            $this->plugin_name = $plugin_name;
            $this->version = $version;

        }

        public function blog_list($atts, $content)
        {

            $atts = shortcode_atts(
                array(
                    'limit' => get_option('posts_per_page'),
                    'column' => 3,
                ),
                $atts,
                'blog_list'
            );

            $loop_args = array(
                'post_type' => 'blogs',
                'posts_per_page' => $atts['limit'],
            );

            $loop = new WP_Query($loop_args);

            $grid_column = bps_get_column_class($atts['column']);

            ob_start();
            ?>
            <div class="cpt-blogs <?php echo $grid_column; ?>" id="cpt-main-sec" >
<?php

            while ($loop->have_posts()):

                $loop->the_post();
                include BLOG_POST_BASE_DIR . 'templates/archive/content-blog.php';

            endwhile;

            wp_reset_postdata();

            ?>
</div>
<?php
return ob_get_clean();
        }

    }
}
