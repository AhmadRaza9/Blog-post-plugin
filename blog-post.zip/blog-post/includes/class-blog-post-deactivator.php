<?php

/**
 * Fired during plugin deactivation
 *
 * @link       https://ahmadraza.ga
 * @since      1.0.0
 *
 * @package    Blog_Post
 * @subpackage Blog_Post/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Blog_Post
 * @subpackage Blog_Post/includes
 * @author     Ahmad raza <raza.ataki@gmail.com>
 */
class Blog_Post_Deactivator
{

    /**
     * Short Description. (use period)
     *
     * Long Description.
     *
     * @since    1.0.0
     */

    public static function deactivate()
    {

    }

}
