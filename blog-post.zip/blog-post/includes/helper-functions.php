<?php

// If this file is call directyl, abort.
if (!defined('ABSPATH')) {
    die;
}

if (!function_exists("bps_get_column_class")) {

/**
 * @param  $int int
 * @return $css_class string
 */

    function bps_get_column_class($int)
    {
        switch ($int) {
            case (1):
                return 'column-one';
                break;
            case (2):
                return 'column-two';
                break;

            case (3):
                return 'column-three';
                break;

            case (4):
                return 'column-four';
                break;

            default:
                return 'column-three';
        }
    }

}
