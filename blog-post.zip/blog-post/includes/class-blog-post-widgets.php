<?php

// If this file is call directyl, abort.
if (!defined('ABSPATH')) {
    die;
}

/**
 * Controlling all the widgets for plugin
 *
 * @package Blog_Post
 * @subpackage Blog_Post/includes
 * @author Ahmad <raza.ataki@gmail.com>
 */

if (!class_exists('Blog_Post_Widgets')) {
    class Blog_Post_Widgets
    {

        /**
         * The ID of this plugin.
         *
         * @since 1.0.0
         * @access private
         * @var string $plugin_name This id of this plugin
         */

        private $plugin_name;

        /**
         * The version of this plugin
         *
         * @since 1.0.0
         * @access private
         * @param string $plugin_version The Current version of this plugin
         */

        private $version;

        /**
         * Initialize the class and set its properties
         * @since 1.0.0
         * @param string $plugin_name The name of the plugin.
         * @param string $version The version of this plugin.
         */

        public function __construct($plugin_name, $version)
        {
            $this->plugin_name = $plugin_name;
            $this->version = $version;
            // $this->register_widgets();
        }

        /**
         * Load Widget Class Deps
         */

        public function load_dependency()
        {

        }

        /**
         * Register widgets for the plugin
         */

        public function register_widgets()
        {

            require_once BLOG_POST_BASE_DIR . 'includes/widgets/class-blog-post-widgets-list.php';
            register_widget('Blog_Post_Widgets_List');

        }

    }
}
