<?php

// If this file is call directyl, abort.
if (!defined('ABSPATH')) {
    die;
}

/**
 *
 * @link       https://ahmadraza.ga
 * @since      1.0.0
 *
 * @package    Blog_Post
 * @subpackage Blog_Post/includes
 */

/**
 * The core plugin class.
 *
 * This is used to define internationalization, admin-specific hooks, and
 * public-facing site hooks.
 *
 * Also maintains the unique identifier of this plugin as well as the current
 * version of the plugin.
 *
 * @since      1.0.0
 * @package    Blog_Post
 * @subpackage Blog_Post/includes
 * @author     Ahmad raza <raza.ataki@gmail.com>
 */

if (!class_exists('Blog_Post_Types')) {
    class Blog_Post_Types
    {

        /**
         * The ID of this plugin.
         *
         * @since    1.0.0
         * @access   private
         * @var      string    $plugin_name    The ID of this plugin.
         */
        private $plugin_name;

        /**
         * The version of this plugin.
         *
         * @since    1.0.0
         * @access   private
         * @var      string    $version    The current version of this plugin.
         */
        private $version;

        /**
         * Temple loader class
         */

        /**
         * Initialize the class and set its properties.
         *
         * @since    1.0.0
         * @param      string    $plugin_name       The name of the plugin.
         * @param      string    $version    The version of this plugin.
         */
        public function __construct()
        {

            if (defined('BLOG_POST_VERSION')) {
                $this->version = BLOG_POST_VERSION;
            } else {
                $this->version = '1.0.0';
            }
            if (defined('BLOG_POST_NAME')) {
                $this->plugin_name = BLOG_POST_NAME;
            } else {
                $this->plugin_name = 'blog-post';
            }

        }

        /**
         * hooked into 'init' action hook
         */

        public function init()
        {
            // Add cpt and taxonomie  First Step
            $this->register_blog_post_type();
            // $this->register_taxonomy_genre();
            $this->register_taxonomy_Blog_Type();
        }

        /** Add cpt and taxonomie  First Step     **/

        public function register_blog_post_type()
        {
            register_post_type('blogs', array(
                'description' => __('Blogs', 'blog-post'),
                'labels' => array(
                    'name' => _x('Blogs', 'post type general name', 'blog-post'),
                    'singular_namme' => _x('Blog', 'post type singular name', 'blog-post'),
                    'menu_name' => _x('Blogs', 'admin menu', 'blog-post'),
                    'name_admin_bar' => _x('Blog', 'add new Blog on admin bar', 'blog-post'),
                    'add_new' => _x('Add New', 'post_type', 'blog-post'),
                    'add_new_item' => __('Add New Blog', 'blog-post'),
                    'edit_item' => __('Edit Blog', 'blog-post'),
                    'new_item' => __('New Blog', 'blog-post'),
                    'view_item' => __('View Blog', 'blog-post'),
                    'search_item' => __('Search Blog', 'blog-post'),
                    'not_found' => __('No Blogs found', 'blog-post'),
                    'not_found_in_trash' => __('No Blogs found in Trash.', 'blog-post'),
                    'parent_item_colon' => __('Parent Blog:', 'blog-post'),
                    'all_items' => __('All Blogs', 'blog-post'),
                ),
                'public' => true,
                'hierarchical' => false,
                'exclude_from_search' => false,
                'publicly_queryable' => true,
                'show_ui' => true,
                'show_in_menu' => true,
                'show_in_nav_menus' => true,
                'show_in_admin_bar' => true,
                'menu_position' => 20,
                'menu_icon' => 'dashicons-book-alt',
                'capability_type' => 'post',
                'capabilities' => array(),
                'map_meta_cap' => null,
                'supports' => array('title', 'editor', 'author', 'thumbnail', 'excerpt', 'comments'),
                'register_meta_box_cb' => null,
                'taxonomies' => array('genre'),
                'has_archive' => true,
                'rewrite' => array(
                    'slug' => 'blog',
                    'with_front' => true,
                    'feeds' => true,
                    'pages' => true,
                ),
                'query_var' => true,
                'can_export' => true,
                'show_in_rest' => true,
            ));
        }

        public function register_taxonomy_Blog_Type()
        {
            register_taxonomy('blog_type', array('blogs'), array(
                'description' => 'Blog Type',
                'labels' => array(
                    'name' => _x('Blog Type', 'taxonomy general name', 'blog-post'),
                    'singular_name' => _x('Blog Type', 'taxonomy singular name', 'blog-post'),
                    'search_items' => _x('Search Blog Type', 'blog-post'),
                    'popular_items' => _x('Popular Blog Type', 'blog-post'),
                    'all_items' => _x('All Blog Type', 'blog-post'),
                    'parent_item' => _x('Parent Blog Type', 'blog-post'),
                    'parent__item_colon' => _x('Parent Blog Type', 'blog-post'),
                    'edit_item' => _x('Edit Blog Type', 'blog-post'),
                    'view_item' => _x('View Blog Type', 'blog-post'),
                    'update_item' => _x('Update Blog Type', 'blog-post'),
                    'add_new_item' => _x('Add New Blog Type', 'blog-post'),
                    'new_item_name' => _x('New Blog Type Name', 'blog-post'),
                    'separate_items_with_commas' => _x('Separate Blog Type with commas', 'blog-post'),
                    'add_or_remove_items' => _x('Add or remove Blog Type', 'blog-post'),
                    'choose_from_most_user' => _x('Choose from the most used Blog Type', 'blog-post'),
                    'not_found' => _x('No Blog Type found', 'blog-post'),
                ),
                'public' => true,
                'show_ui' => true,
                'show_in_nav_manus' => true,
                'show_in_rest' => true,
                'show_tagcloud' => true,
                'meta_box_cb' => null,
                'show_admin_column' => true,
                'hierarchical' => true,
                'query_var' => 'blog_type',
                'rewrite' => array(
                    'slug' => 'blog_type',
                    'with_front' => true,
                    'hierarchical' => true,
                ),
                'capabilities' => array(),
            ));
        }

/** Add cpt and taxonomie  First Step     **/

/**
 * Second Step  Add metabox using cmb2 framework
 */

        public function register_cmb2_metabox_blog()
        {
            $metabox = new_cmb2_box(array(
                'id' => 'blog-details',
                'title' => __('Blog Details', 'blog-post'),
                'object_types' => array('blogs'),
                'context' => 'normal',
            ));

            $metabox->add_field(array(
                'id' => 'bps_blog_writer',
                'name' => __('Blog Writer', 'blog-post'),
                'type' => 'text',
            ));

            $metabox->add_field(array(
                'id' => 'bps_blog_website_link',
                'name' => __('Writer Website Link', 'blog-post'),
                'type' => 'text',
            ));

            $metabox->add_field(array(
                'id' => 'bps_blog_email_link',
                'name' => __('Writer Email', 'blog-post'),
                'type' => 'text',
            ));

        }

        public function archive_template_blog($template)
        {
            if (is_post_type_archive('blogs')) {
                // template for CPT book
                require_once BLOG_POST_BASE_DIR . 'public/class-blog-post-template-loader.php';
                $template_loader = new BLOG_POST_Template_Loader();

                return $template_loader->get_template_part('archive', 'blog', false);
            }
            return $template;

        }

        /**
         * Fourth Step add gamajo in vendor and add single-blogs in templates and add filter in class-blog-post and us it
         */

        public function single_template_blog($template)
        {

            if (is_singular('blogs')) {
                require_once BLOG_POST_BASE_DIR . 'public/class-blog-post-template-loader.php';
                $template_loader = new BLOG_POST_Template_Loader();

                return $template_loader->get_template_part('single', 'blogs', false);
            }

            return $template;
        }

        /**
         * Third Step load simple template for single blog and create templats folder in this folder we create blog-content.php
         */

        public function content_single_blog($the_content)
        {
            if (in_the_loop()) {
                ob_start();
                require_once BLOG_POST_BASE_DIR . "templates/blog-content.php";
                return ob_get_clean();
            }

            return $the_content;

        }
        /**
         * Small Archive Blog Excerpt Length
         */

        public function archive_blog_excerpt_length()
        {
            return 20;
        }

    }
}
