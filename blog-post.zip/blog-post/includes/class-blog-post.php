<?php

/**
 * The file that defines the core plugin class
 *
 * A class definition that includes attributes and functions used across both the
 * public-facing side of the site and the admin area.
 *
 * @link       https://ahmadraza.ga
 * @since      1.0.0
 *
 * @package    Blog_Post
 * @subpackage Blog_Post/includes
 */

/**
 * The core plugin class.
 *
 * This is used to define internationalization, admin-specific hooks, and
 * public-facing site hooks.
 *
 * Also maintains the unique identifier of this plugin as well as the current
 * version of the plugin.
 *
 * @since      1.0.0
 * @package    Blog_Post
 * @subpackage Blog_Post/includes
 * @author     Ahmad raza <raza.ataki@gmail.com>
 */
class Blog_Post
{

    /**
     * The loader that's responsible for maintaining and registering all hooks that power
     * the plugin.
     *
     * @since    1.0.0
     * @access   protected
     * @var      Blog_Post_Loader    $loader    Maintains and registers all hooks for the plugin.
     */
    protected $loader;

    /**
     * The unique identifier of this plugin.
     *
     * @since    1.0.0
     * @access   protected
     * @var      string    $plugin_name    The string used to uniquely identify this plugin.
     */
    protected $plugin_name;

    /**
     * The current version of the plugin.
     *
     * @since    1.0.0
     * @access   protected
     * @var      string    $version    The current version of the plugin.
     */
    protected $version;

    /**
     * Define the core functionality of the plugin.
     *
     * Set the plugin name and the plugin version that can be used throughout the plugin.
     * Load the dependencies, define the locale, and set the hooks for the admin area and
     * the public-facing side of the site.
     *
     * @since    1.0.0
     */
    public function __construct()
    {
        if (defined('BLOG_POST_VERSION')) {
            $this->version = BLOG_POST_VERSION;
        } else {
            $this->version = '1.0.0';
        }
        $this->plugin_name = 'blog-post';

        $this->load_dependencies();
        $this->set_locale();
        $this->define_admin_hooks();
        $this->define_public_hooks();
        $this->define_blog_post_type_hooks();
        $this->define_shortcodes_hooks();
        $this->define_widgets_hooks();

    }

    /**
     * Load the required dependencies for this plugin.
     *
     * Include the following files that make up the plugin:
     *
     * - Blog_Post_Loader. Orchestrates the hooks of the plugin.
     * - Blog_Post_i18n. Defines internationalization functionality.
     * - Blog_Post_Admin. Defines all hooks for the admin area.
     * - Blog_Post_Public. Defines all hooks for the public side of the site.
     *
     * Create an instance of the loader which will be used to register the hooks
     * with WordPress.
     *
     * @since    1.0.0
     * @access   private
     */
    private function load_dependencies()
    {

        /**
         * The class responsible for orchestrating the actions and filters of the
         * core plugin.
         */
        require_once plugin_dir_path(dirname(__FILE__)) . 'includes/class-blog-post-loader.php';

        /**
         * The class responsible for defining internationalization functionality
         * of the plugin.
         */
        require_once plugin_dir_path(dirname(__FILE__)) . 'includes/class-blog-post-i18n.php';

        /**
         * Contains helper functions
         */
        require_once plugin_dir_path(dirname(__FILE__)) . 'includes/helper-functions.php';

        /**
         * requiring CMB2 init file for meta boxes
         */
        require_once plugin_dir_path(dirname(__FILE__)) . 'vendor/CMB2/init.php';

        /**
         * The class responsible for defining all actions that occur in the admin area.
         */
        require_once plugin_dir_path(dirname(__FILE__)) . 'admin/class-blog-post-admin.php';

        /**
         * The class responsible for defining all actions that occur in the public-facing
         * side of the site.
         * Add cpt and taxonomie  First Step
         */
        require_once plugin_dir_path(dirname(__FILE__)) . 'public/class-blog-post-public.php';

        // Add cpt and taxonomie  First Step
        require_once plugin_dir_path(dirname(__FILE__)) . 'includes/class-blog-post-type.php';
        /**
         * The class responsible for defining all shortocodes
         */
        require_once plugin_dir_path(dirname(__FILE__)) . 'includes/class-blog-post-shortcode.php';

        /**
         * The class responsivle for defining all widgets
         */

        require_once plugin_dir_path(dirname(__FILE__)) . 'includes/class-blog-post-widgets.php';

        $this->loader = new Blog_Post_Loader();

    }

    /**
     * Define the locale for this plugin for internationalization.
     *
     * Uses the Blog_Post_i18n class in order to set the domain and to register the hook
     * with WordPress.
     *
     * @since    1.0.0
     * @access   private
     */
    private function set_locale()
    {

        $plugin_i18n = new Blog_Post_i18n();

        $this->loader->add_action('plugins_loaded', $plugin_i18n, 'load_plugin_textdomain');

    }

    /**
     * Register all of the hooks related to the admin area functionality
     * of the plugin.
     *
     * @since    1.0.0
     * @access   private
     */
    private function define_admin_hooks()
    {

        $plugin_admin = new Blog_Post_Admin($this->get_plugin_name(), $this->get_version());

        $this->loader->add_action('admin_enqueue_scripts', $plugin_admin, 'enqueue_styles');
        $this->loader->add_action('admin_enqueue_scripts', $plugin_admin, 'enqueue_scripts');

        /**
         * Plugin Settings Page
         */

        $this->loader->add_action('admin_menu', $plugin_admin, 'plugin_menu_settings_using_boo_helper');

    }

    /**
     * Register all of the hooks related to the public-facing functionality
     * of the plugin.
     *
     * @since    1.0.0
     * @access   private
     */
    private function define_public_hooks()
    {

        $plugin_public = new Blog_Post_Public($this->get_plugin_name(), $this->get_version());

        $this->loader->add_action('wp_enqueue_scripts', $plugin_public, 'enqueue_styles');
        $this->loader->add_action('wp_enqueue_scripts', $plugin_public, 'enqueue_scripts');
    }

    /**
     * Run the loader to execute all of the hooks with WordPress.
     *
     * @since    1.0.0
     */
    public function run()
    {
        $this->loader->run();
    }

    /**
     * The name of the plugin used to uniquely identify it within the context of
     * WordPress and to define internationalization functionality.
     *
     * @since     1.0.0
     * @return    string    The name of the plugin.
     */
    public function get_plugin_name()
    {
        return $this->plugin_name;
    }

    /**
     * The reference to the class that orchestrates the hooks with the plugin.
     *
     * @since     1.0.0
     * @return    Blog_Post_Loader    Orchestrates the hooks of the plugin.
     */
    public function get_loader()
    {
        return $this->loader;
    }

    /**
     * Retrieve the version number of the plugin.
     *
     * @since     1.0.0
     * @return    string    The version number of the plugin.
     */
    public function get_version()
    {
        return $this->version;
    }

    /**
     * Add cpt and taxonomie  First Step
     */

    public function define_blog_post_type_hooks()
    {
        $plugin_post_types = new Blog_Post_Types($this->get_plugin_name(), $this->get_version());

        $this->loader->add_action('init', $plugin_post_types, 'init');

        /**
         * Second Step  Add metabox using cmb2 framework
         */

        $this->loader->add_action('cmb2_admin_init', $plugin_post_types, 'register_cmb2_metabox_blog');

/**
 * Third Step load simple template for single blog and create templats folder in this folder we create blog-content.php
 */
        // unload blog-content.php
        // $this->loader->add_filter('the_content', $plugin_post_types, 'content_single_blog');

        /**
         * Fourth Step add gamajo in vendor and add single-blogs in templates and add filter in class-blog-post and us it
         */

        $this->loader->add_filter('single_template', $plugin_post_types, 'single_template_blog');

        $this->loader->add_filter('archive_template', $plugin_post_types, 'archive_template_blog');

        $this->loader->add_filter('excerpt_length', $plugin_post_types, 'archive_blog_excerpt_length');

    }

    /**
     * Defining all Shortcode for the plugin
     * [blog_list limit=4 column=3] use shortcode
     */
    public function define_shortcodes_hooks()
    {

        $plugin_shortcode = new Blog_Post_Shortcodes(
            $this->plugin_name,
            $this->version
        );
        add_shortcode('blog_list', array($plugin_shortcode, 'blog_list'));

    }

    /**
     * Defining all Widget for the plugin
     */
    public function define_widgets_hooks()
    {
        $plugin_widget = new Blog_Post_Widgets($this->plugin_name, $this->version);

        $this->loader->add_action('widgets_init', $plugin_widget, 'register_widgets');

        // add_action('widgets_init', function () {
        //     register_widget('My_Widget');
        // });
    }

}

// First Step

/**
 * if template already in templates folder then wordpress use it  (not fully customized)
 *
 * if template already in child theme then wordpress use it
 *
 * if template already in templates folder then wordpress use it (fully customized)
 *
 */
