<?php

if (!class_exists('BLOG_POST_Template_Loader')) {
    if (!class_exists('Gamajo_Template_Loader')) {
        require_once BLOG_POST_BASE_DIR . 'vendor/class-gamajo-template-loader.php';
    }

    class BLOG_POST_Template_Loader extends Gamajo_Template_Loader
    {

        /** Prefix for filter names... */
        protected $filter_prefix = 'blog_post';

        /** Direcotry name where custom templates for this plugin should be found in the theme... */
        protected $theme_template_directory = 'blog-post';

        /** Reference to the root directory path of this plugin */

        protected $plugin_directory = BLOG_POST_BASE_DIR;

        /** Directory name where templates are found in this plugin... */

        protected $plugin_template_directory = 'templates';

    }
}
