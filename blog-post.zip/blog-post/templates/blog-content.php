<div class="blog-content" style="background-color: red;">

<?php echo the_title(); ?>

<?php echo get_the_content(); ?>
</div>
