
<article id="blog-<?php echo get_the_ID(); ?>" class="blog type-blog status-publish format-standard hentry category-uncategorized entry">
		<header class="entry-header">
            <div class="entry-image">
                <?php the_post_thumbnail();?>
            </div>
            <h1 class="entry-title"><?php the_title();?></h1>
            <div class="entry-meta">
                <?php require_once BLOG_POST_BASE_DIR . 'templates/blog-meta.php';?>
	        </div>

	    </header>
        <div class="entry-content">
            <div class="blog-content" >
                <p><?php the_content();?></p>
            </div>
        </div>
</article>
