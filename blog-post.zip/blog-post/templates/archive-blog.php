<?php
/**
 * The template for displaying archive pages
 *
 * Used to display archive-type pages if nothing more specific matches a query.
 * For example, puts together date-based pages if no date.php file exists.
 *
 * If you'd like to further customize these archive views, you may create a
 * new template file for each one. For example, tag.php (Tag archives),
 * category.php (Category archives), author.php (Author archives), etc.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */

$archive_blog_post_order = get_option('bps_blog_post_order');
$archive_blog_post_order_by_date_title = get_option('bps_blog_post_order_by_date_title');
$blog_post_column_layout = get_option('bps_blog_post_column_layout');

$blog_post_column_layout = !empty($blog_post_column_layout) ? $blog_post_column_layout : 'column-three';

$archive_blog_post_order = (!empty($archive_blog_post_order)) ? $archive_blog_post_order : '';
$archive_blog_post_order_by_date_title = (!empty($archive_blog_post_order_by_date_title)) ? $archive_blog_post_order_by_date_title : '';

get_header();

?>

		<?php if (have_posts()): ?>
			<header class="page-header">
				<?php the_archive_title('<h1 class="page-title">', '</h1>');?>
			</header><!-- .page-header -->
            <div class="cpt-blogs <?php echo $blog_post_column_layout; ?>" id="cpt-main-sec" >
<?php

// }

$args = array(
    'post_type' => 'blogs',
    'order' => $archive_blog_post_order ?? '',
    'orderby' => $archive_blog_post_order_by_date_title,
);
// var_dump($args);
query_posts($args);

while (have_posts()):

    the_post();

    include BLOG_POST_BASE_DIR . 'templates/archive/content-blog.php';

    // End the loop.

endwhile;

// Previous/next page navigation.
the_posts_pagination(
    array(
        'prev_text' => __('Previous page', 'twentysixteen'),
        'next_text' => __('Next page', 'twentysixteen'),
        'before_page_number' => '<span class="meta-nav screen-reader-text">' . __('Page', 'twentysixteen') . ' </span>',
    )
);

// If no content, include the "No posts found" template.
else:
?>
    <div class="cpt-cards" id="cpt-main-sec">
    <?php
// get_template_part('template-parts/content', 'none');
echo __("There are no post available");
?>
    </div>
<?php
endif;?>


</div>

<!-- <# ?php get_sidebar();?> -->
<?php get_footer();?>
