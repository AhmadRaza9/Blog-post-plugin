<ul class="book-meta-fields">

    <?php

$meta_fields = array(
    'bps_blog_writer' => __('Writer', 'blog-post'),
    'bps_blog_website_link' => __('Website Link', 'blog-post'),
    'bps_blog_email_link' => __('Email', 'blog-post'),
);

$blog_type_terms = wp_get_post_terms(get_the_ID(), 'blog_type');

// $meta_icons = array(
//     'bps_blog_pages' => "<i class='fa-solid fa-file-invoice'></i>",
//     'bps_is_featured_blog' => "<i class='fa-regular fa-face-grin-stars'></i>",
// );

$html = '';

foreach ($meta_fields as $meta_key => $label) {
    // first : meta value
    $value = esc_html(get_post_meta(get_the_ID(), $meta_key, true));

    if (str_contains($value, 'https://')) {
        $url_text = explode('/', $value, 4);
        $url_link = implode('/', $url_text);
        continue;
    }

    // if its not empty, then we are going build html
    if (empty($value)) {
        continue;
    }
    $html .= "<li><strong>{$label}: </strong>{$value}</li>";

}
echo $html;
echo "<li><strong>Website: </strong><a href='{$url_link}' target='_blank'>{$url_text[2]}</a></li>";

?>

<?php

foreach ($blog_type_terms as $term) {
    if (!empty($term)) {
        echo "<li><strong>Blog Type:</strong> $term->name</li>";
    }
}

?>

</ul>
