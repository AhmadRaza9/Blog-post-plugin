<?php
/**
 * The template for displaying all single posts and attachments
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */

get_header();
?>

		<?php
// Start the loop.
while (have_posts()):
    the_post();

    include BLOG_POST_BASE_DIR . "templates/single/content-blog.php";

    // Previous/next post navigation.
    the_post_navigation(
        array(
            'next_text' => '<span class="meta-nav" aria-hidden="true">' . __('Next', 'blog-post') . '</span> ' .
            '<span class="screen-reader-text">' . __('Next post:', 'blog-post') . '</span> ' .
            '<span class="post-title">%title</span>',
            'prev_text' => '<span class="meta-nav" aria-hidden="true">' . __('Previous', 'blog-post') . '</span> ' .
            '<span class="screen-reader-text">' . __('Previous post:', 'blog-post') . '</span> ' .
            '<span class="post-title">%title</span>',
        )
    );

// End the loop.
endwhile;
?>

<?php get_footer();?>
