<?php

/**
 * Fired when the plugin is uninstalled.
 *
 * When populating this file, consider the following flow
 * of control:
 *
 * - This method should be static
 * - Check if the $_REQUEST content actually is the plugin name
 * - Run an admin referrer check to make sure it goes through authentication
 * - Verify the output of $_GET makes sense
 * - Repeat with other user roles. Best directly by using the links/query string parameters.
 * - Repeat things for multisite. Once for a single site in the network, once sitewide.
 *
 * This file may be updated more in future version of the Boilerplate; however, this is the
 * general skeleton and outline for how the file should work.
 *
 * For more information, see the following discussion:
 * https://github.com/tommcfarlin/WordPress-Plugin-Boilerplate/pull/123#issuecomment-28541913
 *
 * @link       https://ahmadraza.ga
 * @since      1.0.0
 *
 * @package    Blog_Post
 */

// If uninstall not called from WordPress, then exit.
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

// Remove Options

$option_ids_to_delete = array(
    0 => 'bps_blog_writer',
    1 => 'blog_type',
    2 => 'bps_blog_website_link',
    3 => 'bps_blog_email_link',
);

// Remove Widget Options

if (current_user_can('manage_options')) {
    foreach ($option_ids_to_delete as $option_id) {
        delete_option($optioin_id);
    }
}
