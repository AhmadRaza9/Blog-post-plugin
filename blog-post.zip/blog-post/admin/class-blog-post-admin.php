<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       https://ahmadraza.ga
 * @since      1.0.0
 *
 * @package    Blog_Post
 * @subpackage Blog_Post/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Blog_Post
 * @subpackage Blog_Post/admin
 * @author     Ahmad raza <raza.ataki@gmail.com>
 */
class Blog_Post_Admin
{

    /**
     * The ID of this plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $plugin_name    The ID of this plugin.
     */
    private $plugin_name;

    /**
     * The version of this plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $version    The current version of this plugin.
     */
    private $version;

    /**
     * Initialize the class and set its properties.
     *
     * @since    1.0.0
     * @param      string    $plugin_name       The name of this plugin.
     * @param      string    $version    The version of this plugin.
     */
    public function __construct($plugin_name, $version)
    {

        $this->plugin_name = $plugin_name;
        $this->version = $version;

    }

    /**
     * Register the stylesheets for the admin area.
     *
     * @since    1.0.0
     */
    public function enqueue_styles()
    {

        /**
         * This function is provided for demonstration purposes only.
         *
         * An instance of this class should be passed to the run() function
         * defined in Blog_Post_Loader as all of the hooks are defined
         * in that particular class.
         *
         * The Blog_Post_Loader will then create the relationship
         * between the defined hooks and the functions defined in this
         * class.
         */

        wp_enqueue_style($this->plugin_name, plugin_dir_url(__FILE__) . 'css/blog-post-admin.css', array(), $this->version, 'all');

    }

    /**
     * Register the JavaScript for the admin area.
     *
     * @since    1.0.0
     */
    public function enqueue_scripts()
    {

        /**
         * This function is provided for demonstration purposes only.
         *
         * An instance of this class should be passed to the run() function
         * defined in Blog_Post_Loader as all of the hooks are defined
         * in that particular class.
         *
         * The Blog_Post_Loader will then create the relationship
         * between the defined hooks and the functions defined in this
         * class.
         */

        wp_enqueue_script($this->plugin_name, plugin_dir_url(__FILE__) . 'js/blog-post-admin.js', array('jquery'), $this->version, false);

    }
    /**
     * Blog Post Plugin Setting
     *
     */
    public function plugin_menu_settings_using_boo_helper()
    {
        require_once BLOG_POST_BASE_DIR . 'vendor/boo-settings-helper/class-boo-settings-helper.php';

        $blog_post_settings = array(
            'tabs' => true,
            'prefix' => 'bps_',
            'menu' => array(
                // 'slug' => 'blog-post',
                'page_title' => __('Blog Post Settings', 'blog-post'),
                'menu_title' => __('Blog Posts', 'blog-post'),
                'parent' => 'edit.php?post_type=blogs',
                'submenu' => true,
            ),
            'sections' => array(
                // General Seciton
                array(
                    'id' => 'bps_general_section',
                    'title' => __('General Section', 'blog-post'),
                    'desc' => __('These are general settings', 'blog-post'),
                ),

                // Advance Seciton
                // array(
                //     'id' => 'bps_advance_section',
                //     'title' => __('Advance Section', 'blog-post'),
                //     'desc' => __('These are advnace settings', 'blog-post'),
                // ),

            ),
            'fields' => array(
                // fields for General Section
                'bps_general_section' => array(
                    array(
                        'id' => 'blog_post_order',
                        'label' => __('Blog Order', 'blog-post'),
                        'type' => 'select',
                        'options' => array(
                            '' => 'Default',
                            'ASC' => 'Accending',
                            'DESC' => 'Decending',
                        ),
                    ),
                    array(
                        'id' => 'blog_post_order_by_date_title',
                        'label' => __('Blog Order By (date & title)', 'blog-post'),
                        'type' => 'select',
                        'options' => array(
                            '' => 'Default',
                            'title' => 'Order By Title',
                            'modified' => 'Order By Date',
                        ),
                    ),
                    array(
                        'id' => 'blog_post_column_layout',
                        'label' => __('Archive Page Layout', 'blog-post'),
                        'type' => 'select',
                        'options' => array(
                            '' => 'Default',
                            'column-one' => 'One Column',
                            'column-two' => 'Two Column',
                            'column-three' => 'Three Column',
                            'column-four' => 'Four Column',
                        ),
                    ),
                ),
            ),
        );
        new Boo_Settings_Helper($blog_post_settings);

    }

}
